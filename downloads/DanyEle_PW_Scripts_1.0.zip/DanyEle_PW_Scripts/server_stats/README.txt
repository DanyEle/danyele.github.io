A web page displaying statistics for Warband servers running the Persistent World module.

To use it you need a web server supporting PHP, in turn supporting cURL and SimpleXML.
Just put the domain name or IP address and the port of your server (or servers) in the
servers_list array in index.php, then copy the files somewhere in the web server document root.

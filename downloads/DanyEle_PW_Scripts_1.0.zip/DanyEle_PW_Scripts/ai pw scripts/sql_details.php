
<?php
$con = mysql_connect("localhost", "DanyEle101", "hrX994QKQMCThPuY") or die(mysql_error());
mysql_select_db("DanyEle101");
?>
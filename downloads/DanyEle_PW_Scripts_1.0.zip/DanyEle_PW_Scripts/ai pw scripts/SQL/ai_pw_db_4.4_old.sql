-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 16, 2014 at 12:37 PM
-- Server version: 5.5.38
-- PHP Version: 5.4.30
 
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
 
 
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
 
--
-- Database: `server1`
--
 
-- --------------------------------------------------------
 
--
-- Table structure for table `admin_permissions`
--
 
CREATE TABLE IF NOT EXISTS `admin_permissions` (
`id` int(5) unsigned NOT NULL,
  `unique_id` int(10) unsigned NOT NULL,
  `server_id` int(5) unsigned NOT NULL,
  `panel` tinyint(1) NOT NULL DEFAULT '0',
  `gold` tinyint(1) NOT NULL DEFAULT '0',
  `kick` tinyint(1) NOT NULL DEFAULT '0',
  `temporary_ban` tinyint(1) NOT NULL DEFAULT '0',
  `permanent_ban` tinyint(1) NOT NULL DEFAULT '0',
  `kill_fade` tinyint(1) NOT NULL DEFAULT '0',
  `freeze` tinyint(1) NOT NULL DEFAULT '0',
  `teleport_self` tinyint(1) NOT NULL DEFAULT '0',
  `admin_items` tinyint(1) NOT NULL DEFAULT '0',
  `heal_self` tinyint(1) NOT NULL DEFAULT '0',
  `godlike_troop` tinyint(1) NOT NULL DEFAULT '0',
  `ships` tinyint(1) NOT NULL DEFAULT '0',
  `announce` tinyint(1) NOT NULL DEFAULT '0',
  `override_poll` tinyint(1) NOT NULL DEFAULT '0',
  `all_items` tinyint(1) NOT NULL DEFAULT '0',
  `mute` tinyint(1) NOT NULL DEFAULT '0',
  `animals` tinyint(1) NOT NULL DEFAULT '0',
  `factions` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `ai_pw_admin_options`
--
 
CREATE TABLE IF NOT EXISTS `ai_pw_admin_options` (
  `id` int(20) unsigned NOT NULL,
  `withdrawal_limit` int(20) unsigned NOT NULL,
  `deposit_limit` int(20) unsigned NOT NULL,
  `spawn_with_weapons` tinyint(1) NOT NULL DEFAULT '1',
  `cleanup_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `cleanup_interval` tinyint(3) unsigned NOT NULL DEFAULT '3',
  `combatlogging_timer` tinyint(3) unsigned NOT NULL DEFAULT '30',
  `default_gold_in_bank` int(20) unsigned NOT NULL,
  `anti_combatlogging_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `chat_commands` tinyint(1) NOT NULL DEFAULT '1'

) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
--
-- Dumping data for table `ai_pw_admin_options`
--
 
INSERT INTO `ai_pw_admin_options` (`id`, `withdrawal_limit`, `deposit_limit`, `spawn_with_weapons`, `cleanup_enabled`, `cleanup_interval`, `combatlogging_timer`, `default_gold_in_bank`, `anti_combatlogging_enabled`, `chat_commands` ) VALUES
(1, 200000, 1000000, 1, 1, 3, 30, 5000, 1, 1);
 
--
-- Table structure for table `ai_pw_houses_item_chests`
--
 
CREATE TABLE IF NOT EXISTS `ai_pw_houses_item_chests` (
  `id` int(10) unsigned NOT NULL,
  `item_slot_200` int(10) unsigned NOT NULL,
  `item_slot_201` int(10) unsigned NOT NULL,
  `item_slot_202` int(10) unsigned NOT NULL,
  `item_slot_203` int(10) unsigned NOT NULL,
  `item_slot_204` int(10) unsigned NOT NULL,
  `item_slot_205` int(10) unsigned NOT NULL,
  `item_slot_206` int(10) unsigned NOT NULL,
  `item_slot_207` int(10) unsigned NOT NULL,
  `item_slot_208` int(10) unsigned NOT NULL,
  `item_slot_209` int(10) unsigned NOT NULL,
  `item_slot_210` int(10) unsigned NOT NULL,
  `item_slot_211` int(10) unsigned NOT NULL,
  `item_slot_212` int(10) unsigned NOT NULL,
  `item_slot_213` int(10) unsigned NOT NULL,
  `item_slot_214` int(10) unsigned NOT NULL,
  `item_slot_215` int(10) unsigned NOT NULL,
  `item_slot_216` int(10) unsigned NOT NULL,
  `item_slot_217` int(10) unsigned NOT NULL,
  `item_slot_218` int(10) unsigned NOT NULL,
  `item_slot_219` int(10) unsigned NOT NULL,
  `item_slot_220` int(10) unsigned NOT NULL,
  `item_slot_221` int(10) unsigned NOT NULL,
  `item_slot_222` int(10) unsigned NOT NULL,
  `item_slot_223` int(10) unsigned NOT NULL,
  `item_slot_224` int(10) unsigned NOT NULL,
  `item_slot_225` int(10) unsigned NOT NULL,
  `item_slot_226` int(10) unsigned NOT NULL,
  `item_slot_227` int(10) unsigned NOT NULL,
  `item_slot_228` int(10) unsigned NOT NULL,
  `item_slot_229` int(10) unsigned NOT NULL,
  `item_slot_230` int(10) unsigned NOT NULL,
  `item_slot_231` int(10) unsigned NOT NULL,
  `item_slot_232` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `ai_pw_player_guids`
--
 
CREATE TABLE IF NOT EXISTS `ai_pw_player_guids` (
`id` int(10) unsigned NOT NULL,
  `name` char(29) CHARACTER SET utf8 DEFAULT NULL,
  `last_scene` text CHARACTER SET utf8,
  `unique_id` int(10) unsigned NOT NULL,
  `gold` int(11) NOT NULL,
  `custom_withdrawal` int(20) unsigned NOT NULL,
  `withdraw_limit` int(20) NOT NULL,
  `deposit_limit` int(20) NOT NULL,
  `horse_hp` int(10) unsigned NOT NULL,
  `health` int(10) unsigned NOT NULL,
  `pos_x` int(10) unsigned NOT NULL,
  `pos_y` int(10) unsigned NOT NULL,
  `pos_z` int(10) unsigned NOT NULL,
  `carried_gold` int(10) unsigned NOT NULL,
  `troop` int(10) unsigned DEFAULT NULL,
  `faction` int(10) unsigned NOT NULL,
  `item_0` int(10) unsigned NOT NULL,
  `item_1` int(10) unsigned NOT NULL,
  `item_2` int(10) unsigned NOT NULL,
  `item_3` int(10) unsigned NOT NULL,
  `body_armor` int(10) unsigned NOT NULL,
  `head_armor` int(10) unsigned NOT NULL,
  `foot_armor` int(10) unsigned NOT NULL,
  `gloves_armor` int(10) unsigned NOT NULL,
  `entry_point` int(10) unsigned NOT NULL,
  `horse` int(10) unsigned NOT NULL,
  `hunger` int(10) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


 
-- --------------------------------------------------------
 
--
-- Table structure for table `clans`
--
 
CREATE TABLE IF NOT EXISTS `clans` (
`id` int(5) unsigned NOT NULL,
  `name` varchar(28) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `clan_players`
--
 
CREATE TABLE IF NOT EXISTS `clan_players` (
`id` int(5) unsigned NOT NULL,
  `clan_id` int(5) unsigned NOT NULL,
  `unique_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `clan_tags`
--
 
CREATE TABLE IF NOT EXISTS `clan_tags` (
`id` int(5) unsigned NOT NULL,
  `clan_id` int(5) unsigned NOT NULL,
  `tag` varchar(28) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `player_names`
--
 
CREATE TABLE IF NOT EXISTS `player_names` (
`id` int(5) unsigned NOT NULL,
  `unique_id` int(10) unsigned NOT NULL,
  `name` varchar(28) NOT NULL,
  `last_used_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inserted_by_warband_server_id` int(5) unsigned DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;
 
-- --------------------------------------------------------
 
--
-- Table structure for table `property_system`
--
 
CREATE TABLE IF NOT EXISTS `property_system` (
`id` int(20) unsigned NOT NULL,
  `property_price` int(20) unsigned NOT NULL,
  `property_owner` int(10) unsigned NOT NULL,
  `property_user1` int(10) unsigned NOT NULL,
  `property_user2` int(10) unsigned NOT NULL,
  `property_user3` int(10) unsigned NOT NULL,
  `property_user4` int(10) unsigned NOT NULL,
  `property_user5` int(10) unsigned NOT NULL,
  `property_user6` int(10) unsigned NOT NULL,
  `property_user7` int(10) unsigned NOT NULL,
  `property_user8` int(10) unsigned NOT NULL,
  `property_user9` int(10) unsigned NOT NULL,
  `purchase_date` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;
 
--
-- Dumping data for table `property_system`
--
 
INSERT INTO `property_system` (`id`, `property_price`, `property_owner`, `purchase_date`) VALUES
(1, 75000, 0, '0000-00-00 00:00:00');
 
-- --------------------------------------------------------
 
--
-- Table structure for table `warband_servers`
--
 
CREATE TABLE IF NOT EXISTS `warband_servers` (
`id` int(5) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` char(40) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
 
--
-- Dumping data for table `warband_servers`
--
 
INSERT INTO `warband_servers` (`id`, `name`, `password`) VALUES
(1, 'server1', '2eb465c352d3ea489522308726025a371488e021');
 
--
-- Indexes for dumped tables
--
 
--
-- Indexes for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `server_id` (`server_id`,`unique_id`);
 
--
-- Indexes for table `ai_pw_admin_options`
--
ALTER TABLE `ai_pw_admin_options`
 ADD UNIQUE KEY `id` (`id`);
 
 
--
-- Indexes for table `ai_pw_houses_item_chests`
--
ALTER TABLE `ai_pw_houses_item_chests`
 ADD PRIMARY KEY (`id`);
 
--
-- Indexes for table `ai_pw_player_guids`
--
ALTER TABLE `ai_pw_player_guids`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `myindex` (`unique_id`);
 
--
-- Indexes for table `clans`
--
ALTER TABLE `clans`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);
 
--
-- Indexes for table `clan_players`
--
ALTER TABLE `clan_players`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `clan_id` (`clan_id`,`unique_id`);
 
--
-- Indexes for table `clan_tags`
--
ALTER TABLE `clan_tags`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `tag` (`tag`);
 
--
-- Indexes for table `player_names`
--
ALTER TABLE `player_names`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`), ADD KEY `unique_id` (`unique_id`);
 
--
-- Indexes for table `property_system`
--
ALTER TABLE `property_system`
 ADD PRIMARY KEY (`id`);
 
--
-- Indexes for table `warband_servers`
--
ALTER TABLE `warband_servers`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `password` (`password`);
 
--
-- AUTO_INCREMENT for dumped tables
--
 
--
-- AUTO_INCREMENT for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ai_pw_player_guids`
--
ALTER TABLE `ai_pw_player_guids`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clans`
--
ALTER TABLE `clans`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clan_players`
--
ALTER TABLE `clan_players`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clan_tags`
--
ALTER TABLE `clan_tags`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `player_names`
--
ALTER TABLE `player_names`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `property_system`
--
ALTER TABLE `property_system`
MODIFY `id` int(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `warband_servers`
--
ALTER TABLE `warband_servers`
MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;